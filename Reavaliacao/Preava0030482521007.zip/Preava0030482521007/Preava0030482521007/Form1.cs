﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Preava0030482521007
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void butExe_Click(object sender, EventArgs e)
        {

            double[] matrizA = new double[10];
            double[] matrizB = new double[10];
            string aux = " ";
            double po = 0;
            

            for (int i = 0; i < matrizA.Length; i++)
            {
                aux = Interaction.InputBox($"Digite Numero {i + 1}");
                if (!double.TryParse(aux, out matrizA[i]))
                {
                    MessageBox.Show("valor invalido!");
                    i--;
                }


                if (matrizA[i] < 0)
                {
                    MessageBox.Show("VALOR INVALIDO!");
                    i--;
                }
            }

            for(int i = 0;i < matrizB.Length;i++)
            {
                
                if ( matrizA[i] % 2 == po)
                {
                    matrizB[i] = matrizA[i] * 4;
                }
                else
                {
                    matrizB[i] = matrizA[i] + 4;
                }
            }

            for (int i = 0; i < matrizA.Length; i++)
            {
                lbox.Items.Add("Posição: " + i + " Matriz A = "+ matrizA[i] + " Matriz B = " + matrizB[i]);
            }


        }

        private void butClear_Click(object sender, EventArgs e)
        {
            lbox.Items.Clear();
        }
    }
}
