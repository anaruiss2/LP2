﻿namespace Preava0030482521007
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.butClear = new System.Windows.Forms.Button();
            this.lbox = new System.Windows.Forms.ListBox();
            this.butExe = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butClear
            // 
            this.butClear.Location = new System.Drawing.Point(161, 207);
            this.butClear.Name = "butClear";
            this.butClear.Size = new System.Drawing.Size(89, 47);
            this.butClear.TabIndex = 1;
            this.butClear.Text = "Limpar";
            this.butClear.UseVisualStyleBackColor = true;
            this.butClear.Click += new System.EventHandler(this.butClear_Click);
            // 
            // lbox
            // 
            this.lbox.FormattingEnabled = true;
            this.lbox.ItemHeight = 20;
            this.lbox.Location = new System.Drawing.Point(323, 130);
            this.lbox.Name = "lbox";
            this.lbox.Size = new System.Drawing.Size(342, 224);
            this.lbox.TabIndex = 2;
            // 
            // butExe
            // 
            this.butExe.Location = new System.Drawing.Point(161, 130);
            this.butExe.Name = "butExe";
            this.butExe.Size = new System.Drawing.Size(89, 55);
            this.butExe.TabIndex = 3;
            this.butExe.Text = "Executar";
            this.butExe.UseVisualStyleBackColor = true;
            this.butExe.Click += new System.EventHandler(this.butExe_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.butExe);
            this.Controls.Add(this.lbox);
            this.Controls.Add(this.butClear);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butClear;
        private System.Windows.Forms.ListBox lbox;
        private System.Windows.Forms.Button butExe;
    }
}

