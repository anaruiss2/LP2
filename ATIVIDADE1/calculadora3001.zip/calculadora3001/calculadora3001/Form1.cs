namespace calculadora3001
{
    public partial class Form1 : Form
    {
        double num1;
        double num2;
        double resul;

        public Form1()
        {
            InitializeComponent();
        }





        private void plus_Click(object sender, EventArgs e)
        {
            resul = num1 + num2;
            txtResult.Text = resul.ToString();

        }

        private void txtNumber1_Validated(object sender, EventArgs e)
        {

            if (this.ActiveControl == exit)
            {
                return;
            }

            if (!double.TryParse(txtNumber1.Text, out num1))
            {
                MessageBox.Show("Numero 1 invalido!");
                txtNumber1.Focus();

            }

        }

        private void txtNumber2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == exit)
            {
                return;
            }
            if (!double.TryParse(txtNumber2.Text, out num2))
            {
                MessageBox.Show("Numero 2 invalido!");
                txtNumber2.Focus();
            }
        }

        private void less_Click(object sender, EventArgs e)
        {
            resul = num1 - num2;
            txtResult.Text = resul.ToString();
        }

        private void multi_Click(object sender, EventArgs e)
        {
            resul = num1 * num2;
            txtResult.Text = resul.ToString();
        }

        private void divi_Click(object sender, EventArgs e)
        {
            resul = num1 / num2;
            txtResult.Text = resul.ToString();
        }

        private void clean_Click(object sender, EventArgs e)
        {
            txtNumber1.Clear();
            txtNumber2.Clear();
            txtResult.Clear();
            num2 = 0;
                num1=0;
            resul = 0;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Close();

        }
    }
}
