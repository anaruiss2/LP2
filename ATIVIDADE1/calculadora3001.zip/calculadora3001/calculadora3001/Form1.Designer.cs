﻿namespace calculadora3001
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            number1 = new Label();
            number2 = new Label();
            result = new Label();
            txtNumber1 = new TextBox();
            txtNumber2 = new TextBox();
            txtResult = new TextBox();
            clean = new Button();
            exit = new Button();
            plus = new Button();
            less = new Button();
            multi = new Button();
            divi = new Button();
            SuspendLayout();
            // 
            // number1
            // 
            number1.AutoSize = true;
            number1.Location = new Point(12, 20);
            number1.Name = "number1";
            number1.Size = new Size(92, 25);
            number1.TabIndex = 0;
            number1.Text = "Numero 1";
            // 
            // number2
            // 
            number2.AutoSize = true;
            number2.Location = new Point(12, 54);
            number2.Name = "number2";
            number2.Size = new Size(92, 25);
            number2.TabIndex = 1;
            number2.Text = "Numero 2";
            // 
            // result
            // 
            result.AutoSize = true;
            result.Location = new Point(12, 89);
            result.Name = "result";
            result.Size = new Size(90, 25);
            result.TabIndex = 2;
            result.Text = "Resultado";
            // 
            // txtNumber1
            // 
            txtNumber1.Location = new Point(110, 14);
            txtNumber1.Name = "txtNumber1";
            txtNumber1.Size = new Size(150, 31);
            txtNumber1.TabIndex = 3;
            txtNumber1.Validated += txtNumber1_Validated;
            // 
            // txtNumber2
            // 
            txtNumber2.Location = new Point(110, 51);
            txtNumber2.Name = "txtNumber2";
            txtNumber2.Size = new Size(150, 31);
            txtNumber2.TabIndex = 4;
            txtNumber2.Validated += txtNumber2_Validated;
            // 
            // txtResult
            // 
            txtResult.Location = new Point(110, 88);
            txtResult.Name = "txtResult";
            txtResult.ReadOnly = true;
            txtResult.Size = new Size(150, 31);
            txtResult.TabIndex = 5;
            // 
            // clean
            // 
            clean.Location = new Point(277, 11);
            clean.Name = "clean";
            clean.Size = new Size(112, 34);
            clean.TabIndex = 6;
            clean.Text = "Limpar";
            clean.UseVisualStyleBackColor = true;
            clean.Click += clean_Click;
            // 
            // exit
            // 
            exit.Location = new Point(277, 49);
            exit.Name = "exit";
            exit.Size = new Size(112, 34);
            exit.TabIndex = 7;
            exit.Text = "Sair";
            exit.UseVisualStyleBackColor = true;
            exit.Click += exit_Click;
            // 
            // plus
            // 
            plus.Location = new Point(14, 137);
            plus.Name = "plus";
            plus.Size = new Size(90, 63);
            plus.TabIndex = 8;
            plus.Text = "+";
            plus.UseVisualStyleBackColor = true;
            plus.Click += plus_Click;
            // 
            // less
            // 
            less.Location = new Point(126, 137);
            less.Name = "less";
            less.Size = new Size(89, 63);
            less.TabIndex = 9;
            less.Text = "-";
            less.UseVisualStyleBackColor = true;
            less.Click += less_Click;
            // 
            // multi
            // 
            multi.Location = new Point(233, 137);
            multi.Name = "multi";
            multi.Size = new Size(88, 63);
            multi.TabIndex = 10;
            multi.Text = "x";
            multi.UseVisualStyleBackColor = true;
            multi.Click += multi_Click;
            // 
            // divi
            // 
            divi.Location = new Point(342, 137);
            divi.Name = "divi";
            divi.Size = new Size(88, 63);
            divi.TabIndex = 11;
            divi.Text = "/";
            divi.UseVisualStyleBackColor = true;
            divi.Click += divi_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(divi);
            Controls.Add(multi);
            Controls.Add(less);
            Controls.Add(plus);
            Controls.Add(exit);
            Controls.Add(clean);
            Controls.Add(txtResult);
            Controls.Add(txtNumber2);
            Controls.Add(txtNumber1);
            Controls.Add(result);
            Controls.Add(number2);
            Controls.Add(number1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label number1;
        private Label number2;
        private Label result;
        private TextBox txtNumber1;
        private TextBox txtNumber2;
        private TextBox txtResult;
        private Button clean;
        private Button exit;
        private Button plus;
        private Button less;
        private Button multi;
        private Button divi;
    }
}
