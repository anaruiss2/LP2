﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void but_Click(object sender, EventArgs e)
        {
            double TotalGeral = 0;
            const int dia = 7;
            const int produto = 5;
            double [,] matrizCompra = new double [dia, produto] ;
            double [] Totaldia =new double [dia];

            string[] diaSemana = { "segunda", "terça", "quarta", "quinta", "sexta", "sabado", "domingo" };

            for(int i = 0; i < dia; i++)
            {
                for(int h =0; h < produto; h++)
                {
                    string aux = Interaction.InputBox($"Digite o valor do produto {h + 1} no {diaSemana[i]}", "entrada de dado");
                    if(aux =="")
                    { return; }
                    double valor = Convert.ToDouble(aux);
                    matrizCompra[i, h] = valor;
                    Totaldia[i] += valor;
                    
                }
            }
            for (int i = 0; i < dia; i++)
            {

                TotalGeral += Totaldia[i];

            }

            lbox.Items.Clear();

            lbox.Items.Add("resultado:");
            for (int i = 0;i < dia; i++)
            {
                lbox.Items.Add(diaSemana[i]+ "= R$" +Totaldia[i]);
            }
            lbox.Items.Add("Total: R$" + TotalGeral.ToString());

        }
    }
}
