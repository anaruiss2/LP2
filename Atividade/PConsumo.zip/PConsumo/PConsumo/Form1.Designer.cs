﻿namespace PConsumo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbox = new System.Windows.Forms.ListBox();
            this.but = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbox
            // 
            this.Lbox.FormattingEnabled = true;
            this.Lbox.ItemHeight = 20;
            this.Lbox.Location = new System.Drawing.Point(73, 88);
            this.Lbox.Name = "Lbox";
            this.Lbox.Size = new System.Drawing.Size(346, 244);
            this.Lbox.TabIndex = 0;
            // 
            // but
            // 
            this.but.Location = new System.Drawing.Point(425, 88);
            this.but.Name = "but";
            this.but.Size = new System.Drawing.Size(101, 44);
            this.but.TabIndex = 1;
            this.but.Text = "iniciar";
            this.but.UseVisualStyleBackColor = true;
            this.but.Click += new System.EventHandler(this.but_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.but);
            this.Controls.Add(this.Lbox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox Lbox;
        private System.Windows.Forms.Button but;
    }
}

