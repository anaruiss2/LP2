﻿namespace PFilme02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.butExe = new System.Windows.Forms.Button();
            this.butClear = new System.Windows.Forms.Button();
            this.Opiniao = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // butExe
            // 
            this.butExe.Location = new System.Drawing.Point(143, 103);
            this.butExe.Name = "butExe";
            this.butExe.Size = new System.Drawing.Size(97, 64);
            this.butExe.TabIndex = 0;
            this.butExe.Text = "Executar";
            this.butExe.UseVisualStyleBackColor = true;
            this.butExe.Click += new System.EventHandler(this.butExe_Click);
            // 
            // butClear
            // 
            this.butClear.Location = new System.Drawing.Point(143, 205);
            this.butClear.Name = "butClear";
            this.butClear.Size = new System.Drawing.Size(97, 54);
            this.butClear.TabIndex = 1;
            this.butClear.Text = "Limpar";
            this.butClear.UseVisualStyleBackColor = true;
            this.butClear.Click += new System.EventHandler(this.butClear_Click);
            // 
            // Opiniao
            // 
            this.Opiniao.FormattingEnabled = true;
            this.Opiniao.ItemHeight = 20;
            this.Opiniao.Location = new System.Drawing.Point(298, 103);
            this.Opiniao.Name = "Opiniao";
            this.Opiniao.Size = new System.Drawing.Size(290, 164);
            this.Opiniao.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Opiniao);
            this.Controls.Add(this.butClear);
            this.Controls.Add(this.butExe);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butExe;
        private System.Windows.Forms.Button butClear;
        private System.Windows.Forms.ListBox Opiniao;
    }
}

