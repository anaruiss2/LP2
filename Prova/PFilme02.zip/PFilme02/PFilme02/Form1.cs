﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void butClear_Click(object sender, EventArgs e)
        {
            Opiniao.Items.Clear();
        }

        private void butExe_Click(object sender, EventArgs e)
        {
            
            double pessoas = 2;
            double filmes = 2;
            double[] media = new double[2];
            double[,] ava = new double[2,2];

            for (int i = 0; i < pessoas; i++)
            {

                for (int j = 0; j < filmes; j++)
                {
                    string aux = Interaction.InputBox($"Digite a nota do filme {j + 1}");
                    if (aux == "")
                    { MessageBox.Show("invalido!");
                        return;
                    }
                    if (!double.TryParse(aux, out ava[i, j]) || ava[i, j] < 0 || ava[i,j]> 10)
                    {
                        MessageBox.Show("Numero invalido!");
                        j--;
                    }
                    else
                    {
                        
                    }

                    media[j] += ava[i, j];
                   



                }

                
                   


            }
             for(int i =0;i <filmes;i++)
            {
             media[i] = media[i] / 2;
            }
             
            for (int i = 0; i < pessoas; i++)
            {   
                int j =1;
                int h = 0;
                int k = 1;
                Opiniao.Items.Add("pessoa" + k + ": " +  "nota filme " + j +": "+ ava[i,h]);
                j++;
                h ++;
                k ++;
                Opiniao.Items.Add("Nota filme" + j +": " + ava[i, h]);

            }

            Opiniao.Items.Add("-------------------");

            for (int i = 0;i < filmes;i++)
            {
                int j = 0;
                j++;
                Opiniao.Items.Add("Media filme " + j + ": " + media[i]);
                
            }

        }
    }
}
