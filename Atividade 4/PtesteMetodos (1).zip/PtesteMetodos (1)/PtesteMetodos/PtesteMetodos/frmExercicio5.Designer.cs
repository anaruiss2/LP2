﻿namespace PtesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtboxNum1 = new System.Windows.Forms.TextBox();
            this.txtboxNum2 = new System.Windows.Forms.TextBox();
            this.butRandom = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtboxNum1
            // 
            this.txtboxNum1.Location = new System.Drawing.Point(133, 52);
            this.txtboxNum1.Name = "txtboxNum1";
            this.txtboxNum1.Size = new System.Drawing.Size(100, 26);
            this.txtboxNum1.TabIndex = 0;
            this.txtboxNum1.Validated += new System.EventHandler(this.txtboxNum1_Validated);
            // 
            // txtboxNum2
            // 
            this.txtboxNum2.Location = new System.Drawing.Point(133, 84);
            this.txtboxNum2.Name = "txtboxNum2";
            this.txtboxNum2.Size = new System.Drawing.Size(100, 26);
            this.txtboxNum2.TabIndex = 1;
            this.txtboxNum2.TextChanged += new System.EventHandler(this.txtboxNum2_TextChanged);
            // 
            // butRandom
            // 
            this.butRandom.Location = new System.Drawing.Point(353, 52);
            this.butRandom.Name = "butRandom";
            this.butRandom.Size = new System.Drawing.Size(95, 58);
            this.butRandom.TabIndex = 2;
            this.butRandom.Text = "Sortear";
            this.butRandom.UseVisualStyleBackColor = true;
            this.butRandom.Click += new System.EventHandler(this.butRandom_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.butRandom);
            this.Controls.Add(this.txtboxNum2);
            this.Controls.Add(this.txtboxNum1);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.Load += new System.EventHandler(this.frmExercicio5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtboxNum1;
        private System.Windows.Forms.TextBox txtboxNum2;
        private System.Windows.Forms.Button butRandom;
    }
}