﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butContaNum = new System.Windows.Forms.Button();
            this.butCaracterBranco = new System.Windows.Forms.Button();
            this.butContaLetras = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // butContaNum
            // 
            this.butContaNum.Location = new System.Drawing.Point(84, 153);
            this.butContaNum.Name = "butContaNum";
            this.butContaNum.Size = new System.Drawing.Size(91, 54);
            this.butContaNum.TabIndex = 0;
            this.butContaNum.Text = "Conta numeros";
            this.butContaNum.UseVisualStyleBackColor = true;
            this.butContaNum.Click += new System.EventHandler(this.butContaNum_Click);
            // 
            // butCaracterBranco
            // 
            this.butCaracterBranco.Location = new System.Drawing.Point(218, 153);
            this.butCaracterBranco.Name = "butCaracterBranco";
            this.butCaracterBranco.Size = new System.Drawing.Size(96, 54);
            this.butCaracterBranco.TabIndex = 1;
            this.butCaracterBranco.Text = "1º caracter em branco";
            this.butCaracterBranco.UseVisualStyleBackColor = true;
            this.butCaracterBranco.Click += new System.EventHandler(this.button2_Click);
            // 
            // butContaLetras
            // 
            this.butContaLetras.Location = new System.Drawing.Point(341, 153);
            this.butContaLetras.Name = "butContaLetras";
            this.butContaLetras.Size = new System.Drawing.Size(82, 54);
            this.butContaLetras.TabIndex = 2;
            this.butContaLetras.Text = "Conta letras";
            this.butContaLetras.UseVisualStyleBackColor = true;
            this.butContaLetras.Click += new System.EventHandler(this.butContaLetras_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(103, 12);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(298, 95);
            this.rchtxtFrase.TabIndex = 3;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.butContaLetras);
            this.Controls.Add(this.butCaracterBranco);
            this.Controls.Add(this.butContaNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butContaNum;
        private System.Windows.Forms.Button butCaracterBranco;
        private System.Windows.Forms.Button butContaLetras;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}