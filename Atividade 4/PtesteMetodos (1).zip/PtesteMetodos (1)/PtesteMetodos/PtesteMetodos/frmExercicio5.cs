﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form


    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        int num1;
        int num2;
        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void butRandom_Click(object sender, EventArgs e)
        {

            System.Random gerador = new System.Random();



            int numero = (gerador.Next(num1, num2));
            MessageBox.Show("Numero sorteado:" + numero);

        }

        private void txtboxNum1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtboxNum1.Text, out num1))
            {
                MessageBox.Show("Digite um numero!");
                txtboxNum1.Focus();
            }
        }

        private void txtboxNum2_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(txtboxNum2.Text, out num2))
            {
                MessageBox.Show("Digite um numero!");
                txtboxNum1.Focus();
            }
        }



    }
}
    

